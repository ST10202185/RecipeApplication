﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Recipe1.Commands;
using Recipe1.Model;
using Recipe1.Models;
using Recipe1.Views;

namespace Recipe1.ViewModel
{
    public class MainViewModel
    {
        public ObservableCollection<Recipe> Recipes { get; set; }

        public ICommand ShowWindowCommand { get; set; }

        public MainViewModel()
        {
            Recipes = RecipeManager.GetRecipes();

            ShowWindowCommand = new RelayCommand(ShowWindow, CanShowWindow);

        }

        private bool CanShowWindow(object obj)
        {
            return true;
        }

        private void ShowWindow(object obj)
        {
            AddRecipe addRecipeWin = new AddRecipe();
            addRecipeWin.Show();

        }
    }
}
