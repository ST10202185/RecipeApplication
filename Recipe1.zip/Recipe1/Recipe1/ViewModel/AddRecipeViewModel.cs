﻿using Recipe1.Commands;
using Recipe1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Recipe1.ViewModel
{
    public class AddRecipeViewModel
    {
        public ICommand AddRecipeCommand { get; set; }

        public string? Name { get; set; }
        public int Ingredients { get; set; }
        public string? Details { get; set; }
        public int Quantity { get; set; }
        public string? Units { get; set; }
        public int Calories { get; set; }
        public string? Group { get; set; }
        public int Steps { get; set; }
        public string? Description { get; set; }

        public AddRecipeViewModel()
        {
            AddRecipeCommand = new RelayCommand(AddRecipe, CanAddRecipe);
        }

        private bool CanAddRecipe(object obj)
        {
            return true;
        }

        private void AddRecipe(object obj)
        {
            RecipeManager.AddRecipe(new Models.Recipe() { Name = Name, Ingredients = Ingredients, Details = Details, Quantity = Quantity, Units = Units, Calories = Calories, Group = Group, Steps = Steps, Description = Description });
        }
    }
}
