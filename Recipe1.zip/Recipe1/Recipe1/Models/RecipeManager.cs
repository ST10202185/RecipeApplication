﻿using Recipe1.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe1.Model
{
    public class RecipeManager
    {
        public static ObservableCollection<Recipe> Recipes = new ObservableCollection<Recipe>() { };
        public static ObservableCollection<Recipe> GetRecipes() { return Recipes; }
        public static void AddRecipe(Recipe recipe)
        {
            Recipes.Add(recipe);
        }
    }
}
