﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe1.Models
{
    public class Recipe
    {
        public Recipe() { }

        public string Name { get; set; }
        public int Ingredients { get; set; }
        public string Details { get; set; }
        public int Quantity { get; set; }
        public string Units { get; set; }
        public int Calories { get; set; }
        public string Group { get; set; }
        public int Steps { get; set; }
        public string Description { get; set; }


    }
}
